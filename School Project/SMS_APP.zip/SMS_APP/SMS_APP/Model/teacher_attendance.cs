﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS_APP.Model
{
   public class teacher_attendance
    {

        public int attendance_id;
        public string teacher_name;
        public DateTime date;
        public char status;
        public string remarks;


    }
}
