﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS_APP.Model
{
   public class exam
    {

        public string exam_id;
        public string exam_type;
    }
}
