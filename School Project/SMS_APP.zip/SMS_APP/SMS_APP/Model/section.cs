﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS_APP.Model
{
    public class section
    {
        public string section_id;
        public string description;
    }
}
