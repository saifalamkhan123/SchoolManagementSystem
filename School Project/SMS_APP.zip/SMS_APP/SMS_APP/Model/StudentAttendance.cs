﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS_APP.Model
{
    public class StudentAttendance
    {
        public int attendanceStudentId;
        public string StudentName;
        public DateTime date;
        public char status;
        public string remarks;
        public int studentId;
    }
}

