﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS_APP.Model
{
    public class Student
    {
        public int studentId;
        public string studentName;
        public string gender;
        public DateTime dob;
        public DateTime doJoining;
        public int className;
        public string section;
        public int mobileNo;
        public string address;
        public string city;
        public int parentsId;
        
               
    }
}


