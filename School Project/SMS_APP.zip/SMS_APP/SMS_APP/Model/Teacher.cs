﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS_APP.Model
{
    public class Teacher
    {

        public int teacherId;
        public string teacherName;
        public int nicNo;
        public string gender;
        public DateTime doJoining;
        public string qualification;
        public int mobileNo;
        public string Address;
        public string city;
        
    }
}


