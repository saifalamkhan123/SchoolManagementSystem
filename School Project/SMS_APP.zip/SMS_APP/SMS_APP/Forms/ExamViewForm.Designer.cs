﻿namespace SMS_APP.Forms
{
    partial class ExamViewForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.dgvExam = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.btnRefresh = new System.Windows.Forms.Button();
            this.EXAM_ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.EXAM_TYPE = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.GridViewUpdate = new System.Windows.Forms.DataGridViewButtonColumn();
            this.GridViewDelete = new System.Windows.Forms.DataGridViewButtonColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dgvExam)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvExam
            // 
            this.dgvExam.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvExam.BackgroundColor = System.Drawing.Color.White;
            this.dgvExam.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvExam.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.EXAM_ID,
            this.EXAM_TYPE,
            this.GridViewUpdate,
            this.GridViewDelete});
            this.dgvExam.Location = new System.Drawing.Point(56, 123);
            this.dgvExam.Name = "dgvExam";
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvExam.RowHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dgvExam.Size = new System.Drawing.Size(686, 217);
            this.dgvExam.TabIndex = 14;
            this.dgvExam.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvExam_CellClick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(261, 56);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(151, 20);
            this.label1.TabIndex = 13;
            this.label1.Text = "Exam Detail Form";
            // 
            // btnRefresh
            // 
            this.btnRefresh.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnRefresh.Location = new System.Drawing.Point(545, 361);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(109, 44);
            this.btnRefresh.TabIndex = 15;
            this.btnRefresh.Text = "REFRESH";
            this.btnRefresh.UseVisualStyleBackColor = false;
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
            // 
            // EXAM_ID
            // 
            this.EXAM_ID.DataPropertyName = "EXAM_ID";
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            this.EXAM_ID.DefaultCellStyle = dataGridViewCellStyle1;
            this.EXAM_ID.HeaderText = "EXAM ID";
            this.EXAM_ID.Name = "EXAM_ID";
            // 
            // EXAM_TYPE
            // 
            this.EXAM_TYPE.DataPropertyName = "EXAM_TYPE";
            this.EXAM_TYPE.HeaderText = "EXAM TYPE";
            this.EXAM_TYPE.Name = "EXAM_TYPE";
            // 
            // GridViewUpdate
            // 
            this.GridViewUpdate.HeaderText = "UPDATE";
            this.GridViewUpdate.Name = "GridViewUpdate";
            this.GridViewUpdate.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.GridViewUpdate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.GridViewUpdate.Text = "UPDATE";
            this.GridViewUpdate.UseColumnTextForButtonValue = true;
            // 
            // GridViewDelete
            // 
            this.GridViewDelete.HeaderText = "DELETE";
            this.GridViewDelete.Name = "GridViewDelete";
            this.GridViewDelete.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.GridViewDelete.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.GridViewDelete.Text = "DELETE";
            this.GridViewDelete.UseColumnTextForButtonValue = true;
            // 
            // ExamViewForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnRefresh);
            this.Controls.Add(this.dgvExam);
            this.Controls.Add(this.label1);
            this.Name = "ExamViewForm";
            this.Text = "ExamViewForm";
            this.Load += new System.EventHandler(this.ExamViewForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvExam)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvExam;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnRefresh;
        private System.Windows.Forms.DataGridViewTextBoxColumn EXAM_ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn EXAM_TYPE;
        private System.Windows.Forms.DataGridViewButtonColumn GridViewUpdate;
        private System.Windows.Forms.DataGridViewButtonColumn GridViewDelete;
    }
}