﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;



namespace SMS_APP.Forms
{
    public partial class TimeTableViewForm : Form
    {
        public TimeTableViewForm()
        {
            InitializeComponent();
        }


        private void DisplayData()
        {
            SqlConnection con = new SqlConnection("Data Source=DESKTOP-B1GS0NE;Initial Catalog=SMS;Integrated Security=True");

            con.Open();
            DataTable dt = new DataTable();

            SqlDataAdapter adapt;
            adapt = new SqlDataAdapter("select * from class_time_table", con);
            adapt.Fill(dt);
            dgvTimeTable.DataSource = dt;
            con.Close();
        }


        private void TimeTableViewForm_Load(object sender, EventArgs e)
        {
            dgvTimeTable.ColumnHeadersDefaultCellStyle.BackColor = Color.LightPink;
            dgvTimeTable.EnableHeadersVisualStyles = false;

            DisplayData();

        }
    }
}
