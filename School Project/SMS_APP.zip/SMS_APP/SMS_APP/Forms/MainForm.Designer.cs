﻿namespace SMS_APP
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addStudentFormToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addTeacherFormToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addParentsFormToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addCourseFormToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addAttendanceFormToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addTeacherAttendanceFormToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.addClassTimeTableToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addClassNameToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addSectionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addExamToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addExamScoreToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addFeeStructureToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.studentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.teacherToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.parentsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.courseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.attendanceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.attendanceTeacherToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.classToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.classNameToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.classTimeTableToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.examToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.examTypeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.examScoreToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sectionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.examToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.applicationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.developerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.editToolStripMenuItem,
            this.aboutToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addStudentFormToolStripMenuItem,
            this.addTeacherFormToolStripMenuItem,
            this.addParentsFormToolStripMenuItem,
            this.addCourseFormToolStripMenuItem,
            this.addAttendanceFormToolStripMenuItem,
            this.addTeacherAttendanceFormToolStripMenuItem,
            this.toolStripSeparator1,
            this.addClassTimeTableToolStripMenuItem,
            this.addClassNameToolStripMenuItem,
            this.addSectionToolStripMenuItem,
            this.addExamToolStripMenuItem,
            this.addExamScoreToolStripMenuItem,
            this.addFeeStructureToolStripMenuItem,
            this.viewToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // addStudentFormToolStripMenuItem
            // 
            this.addStudentFormToolStripMenuItem.Name = "addStudentFormToolStripMenuItem";
            this.addStudentFormToolStripMenuItem.Size = new System.Drawing.Size(235, 22);
            this.addStudentFormToolStripMenuItem.Text = "Add Student Form";
            this.addStudentFormToolStripMenuItem.Click += new System.EventHandler(this.addStudentFormToolStripMenuItem_Click);
            // 
            // addTeacherFormToolStripMenuItem
            // 
            this.addTeacherFormToolStripMenuItem.Name = "addTeacherFormToolStripMenuItem";
            this.addTeacherFormToolStripMenuItem.Size = new System.Drawing.Size(235, 22);
            this.addTeacherFormToolStripMenuItem.Text = "Add Teacher Form";
            this.addTeacherFormToolStripMenuItem.Click += new System.EventHandler(this.addTeacherFormToolStripMenuItem_Click);
            // 
            // addParentsFormToolStripMenuItem
            // 
            this.addParentsFormToolStripMenuItem.Name = "addParentsFormToolStripMenuItem";
            this.addParentsFormToolStripMenuItem.Size = new System.Drawing.Size(235, 22);
            this.addParentsFormToolStripMenuItem.Text = "Add Parents Form";
            this.addParentsFormToolStripMenuItem.Click += new System.EventHandler(this.addParentsFormToolStripMenuItem_Click);
            // 
            // addCourseFormToolStripMenuItem
            // 
            this.addCourseFormToolStripMenuItem.Name = "addCourseFormToolStripMenuItem";
            this.addCourseFormToolStripMenuItem.Size = new System.Drawing.Size(235, 22);
            this.addCourseFormToolStripMenuItem.Text = "Add Course Form";
            this.addCourseFormToolStripMenuItem.Click += new System.EventHandler(this.addCourseFormToolStripMenuItem_Click);
            // 
            // addAttendanceFormToolStripMenuItem
            // 
            this.addAttendanceFormToolStripMenuItem.Name = "addAttendanceFormToolStripMenuItem";
            this.addAttendanceFormToolStripMenuItem.Size = new System.Drawing.Size(235, 22);
            this.addAttendanceFormToolStripMenuItem.Text = "Add Student Attendance Form";
            this.addAttendanceFormToolStripMenuItem.Click += new System.EventHandler(this.addAttendanceFormToolStripMenuItem_Click);
            // 
            // addTeacherAttendanceFormToolStripMenuItem
            // 
            this.addTeacherAttendanceFormToolStripMenuItem.Name = "addTeacherAttendanceFormToolStripMenuItem";
            this.addTeacherAttendanceFormToolStripMenuItem.Size = new System.Drawing.Size(235, 22);
            this.addTeacherAttendanceFormToolStripMenuItem.Text = "Add Teacher Attendance Form";
            this.addTeacherAttendanceFormToolStripMenuItem.Click += new System.EventHandler(this.addTeacherAttendanceFormToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(232, 6);
            // 
            // addClassTimeTableToolStripMenuItem
            // 
            this.addClassTimeTableToolStripMenuItem.Name = "addClassTimeTableToolStripMenuItem";
            this.addClassTimeTableToolStripMenuItem.Size = new System.Drawing.Size(235, 22);
            this.addClassTimeTableToolStripMenuItem.Text = "Add Class Time Table";
            this.addClassTimeTableToolStripMenuItem.Click += new System.EventHandler(this.addClassTimeTableToolStripMenuItem_Click);
            // 
            // addClassNameToolStripMenuItem
            // 
            this.addClassNameToolStripMenuItem.Name = "addClassNameToolStripMenuItem";
            this.addClassNameToolStripMenuItem.Size = new System.Drawing.Size(235, 22);
            this.addClassNameToolStripMenuItem.Text = "Add Class Name";
            this.addClassNameToolStripMenuItem.Click += new System.EventHandler(this.addClassNameToolStripMenuItem_Click);
            // 
            // addSectionToolStripMenuItem
            // 
            this.addSectionToolStripMenuItem.Name = "addSectionToolStripMenuItem";
            this.addSectionToolStripMenuItem.Size = new System.Drawing.Size(235, 22);
            this.addSectionToolStripMenuItem.Text = "Add Section";
            this.addSectionToolStripMenuItem.Click += new System.EventHandler(this.addSectionToolStripMenuItem_Click);
            // 
            // addExamToolStripMenuItem
            // 
            this.addExamToolStripMenuItem.Name = "addExamToolStripMenuItem";
            this.addExamToolStripMenuItem.Size = new System.Drawing.Size(235, 22);
            this.addExamToolStripMenuItem.Text = "Add Exam";
            this.addExamToolStripMenuItem.Click += new System.EventHandler(this.addExamToolStripMenuItem_Click);
            // 
            // addExamScoreToolStripMenuItem
            // 
            this.addExamScoreToolStripMenuItem.Name = "addExamScoreToolStripMenuItem";
            this.addExamScoreToolStripMenuItem.Size = new System.Drawing.Size(235, 22);
            this.addExamScoreToolStripMenuItem.Text = "Add Exam Score";
            this.addExamScoreToolStripMenuItem.Click += new System.EventHandler(this.addExamScoreToolStripMenuItem_Click);
            // 
            // addFeeStructureToolStripMenuItem
            // 
            this.addFeeStructureToolStripMenuItem.Name = "addFeeStructureToolStripMenuItem";
            this.addFeeStructureToolStripMenuItem.Size = new System.Drawing.Size(235, 22);
            this.addFeeStructureToolStripMenuItem.Text = "Add Fee Structure";
            this.addFeeStructureToolStripMenuItem.Click += new System.EventHandler(this.addFeeStructureToolStripMenuItem_Click);
            // 
            // viewToolStripMenuItem
            // 
            this.viewToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.studentToolStripMenuItem,
            this.teacherToolStripMenuItem,
            this.parentsToolStripMenuItem,
            this.courseToolStripMenuItem,
            this.attendanceToolStripMenuItem,
            this.attendanceTeacherToolStripMenuItem,
            this.classToolStripMenuItem,
            this.examToolStripMenuItem1,
            this.sectionToolStripMenuItem,
            this.toolStripSeparator2,
            this.examToolStripMenuItem});
            this.viewToolStripMenuItem.Name = "viewToolStripMenuItem";
            this.viewToolStripMenuItem.Size = new System.Drawing.Size(235, 22);
            this.viewToolStripMenuItem.Text = "View";
            // 
            // studentToolStripMenuItem
            // 
            this.studentToolStripMenuItem.Name = "studentToolStripMenuItem";
            this.studentToolStripMenuItem.Size = new System.Drawing.Size(179, 22);
            this.studentToolStripMenuItem.Text = "Student";
            this.studentToolStripMenuItem.Click += new System.EventHandler(this.studentToolStripMenuItem_Click);
            // 
            // teacherToolStripMenuItem
            // 
            this.teacherToolStripMenuItem.Name = "teacherToolStripMenuItem";
            this.teacherToolStripMenuItem.Size = new System.Drawing.Size(179, 22);
            this.teacherToolStripMenuItem.Text = "Teacher";
            this.teacherToolStripMenuItem.Click += new System.EventHandler(this.teacherToolStripMenuItem_Click);
            // 
            // parentsToolStripMenuItem
            // 
            this.parentsToolStripMenuItem.Name = "parentsToolStripMenuItem";
            this.parentsToolStripMenuItem.Size = new System.Drawing.Size(179, 22);
            this.parentsToolStripMenuItem.Text = "Parents";
            this.parentsToolStripMenuItem.Click += new System.EventHandler(this.parentsToolStripMenuItem_Click);
            // 
            // courseToolStripMenuItem
            // 
            this.courseToolStripMenuItem.Name = "courseToolStripMenuItem";
            this.courseToolStripMenuItem.Size = new System.Drawing.Size(179, 22);
            this.courseToolStripMenuItem.Text = "Course";
            this.courseToolStripMenuItem.Click += new System.EventHandler(this.courseToolStripMenuItem_Click);
            // 
            // attendanceToolStripMenuItem
            // 
            this.attendanceToolStripMenuItem.Name = "attendanceToolStripMenuItem";
            this.attendanceToolStripMenuItem.Size = new System.Drawing.Size(179, 22);
            this.attendanceToolStripMenuItem.Text = "Attendance Student";
            this.attendanceToolStripMenuItem.Click += new System.EventHandler(this.attendanceToolStripMenuItem_Click);
            // 
            // attendanceTeacherToolStripMenuItem
            // 
            this.attendanceTeacherToolStripMenuItem.Name = "attendanceTeacherToolStripMenuItem";
            this.attendanceTeacherToolStripMenuItem.Size = new System.Drawing.Size(179, 22);
            this.attendanceTeacherToolStripMenuItem.Text = "Attendance Teacher";
            this.attendanceTeacherToolStripMenuItem.Click += new System.EventHandler(this.attendanceTeacherToolStripMenuItem_Click);
            // 
            // classToolStripMenuItem
            // 
            this.classToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.classNameToolStripMenuItem,
            this.classTimeTableToolStripMenuItem});
            this.classToolStripMenuItem.Name = "classToolStripMenuItem";
            this.classToolStripMenuItem.Size = new System.Drawing.Size(179, 22);
            this.classToolStripMenuItem.Text = "Class";
            // 
            // classNameToolStripMenuItem
            // 
            this.classNameToolStripMenuItem.Name = "classNameToolStripMenuItem";
            this.classNameToolStripMenuItem.Size = new System.Drawing.Size(160, 22);
            this.classNameToolStripMenuItem.Text = "Class Name";
            this.classNameToolStripMenuItem.Click += new System.EventHandler(this.classNameToolStripMenuItem_Click);
            // 
            // classTimeTableToolStripMenuItem
            // 
            this.classTimeTableToolStripMenuItem.Name = "classTimeTableToolStripMenuItem";
            this.classTimeTableToolStripMenuItem.Size = new System.Drawing.Size(160, 22);
            this.classTimeTableToolStripMenuItem.Text = "Class Time Table";
            this.classTimeTableToolStripMenuItem.Click += new System.EventHandler(this.classTimeTableToolStripMenuItem_Click);
            // 
            // examToolStripMenuItem1
            // 
            this.examToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.examTypeToolStripMenuItem,
            this.examScoreToolStripMenuItem});
            this.examToolStripMenuItem1.Name = "examToolStripMenuItem1";
            this.examToolStripMenuItem1.Size = new System.Drawing.Size(179, 22);
            this.examToolStripMenuItem1.Text = "Exam";
            // 
            // examTypeToolStripMenuItem
            // 
            this.examTypeToolStripMenuItem.Name = "examTypeToolStripMenuItem";
            this.examTypeToolStripMenuItem.Size = new System.Drawing.Size(135, 22);
            this.examTypeToolStripMenuItem.Text = "Exam Type";
            this.examTypeToolStripMenuItem.Click += new System.EventHandler(this.examTypeToolStripMenuItem_Click);
            // 
            // examScoreToolStripMenuItem
            // 
            this.examScoreToolStripMenuItem.Name = "examScoreToolStripMenuItem";
            this.examScoreToolStripMenuItem.Size = new System.Drawing.Size(135, 22);
            this.examScoreToolStripMenuItem.Text = "Exam Score";
            this.examScoreToolStripMenuItem.Click += new System.EventHandler(this.examScoreToolStripMenuItem_Click);
            // 
            // sectionToolStripMenuItem
            // 
            this.sectionToolStripMenuItem.Name = "sectionToolStripMenuItem";
            this.sectionToolStripMenuItem.Size = new System.Drawing.Size(179, 22);
            this.sectionToolStripMenuItem.Text = "Section";
            this.sectionToolStripMenuItem.Click += new System.EventHandler(this.sectionToolStripMenuItem_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(176, 6);
            // 
            // examToolStripMenuItem
            // 
            this.examToolStripMenuItem.Name = "examToolStripMenuItem";
            this.examToolStripMenuItem.Size = new System.Drawing.Size(179, 22);
            this.examToolStripMenuItem.Text = "Fee Structure";
            this.examToolStripMenuItem.Click += new System.EventHandler(this.examToolStripMenuItem_Click);
            // 
            // editToolStripMenuItem
            // 
            this.editToolStripMenuItem.Name = "editToolStripMenuItem";
            this.editToolStripMenuItem.Size = new System.Drawing.Size(39, 20);
            this.editToolStripMenuItem.Text = "Edit";
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.applicationToolStripMenuItem,
            this.developerToolStripMenuItem});
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(52, 20);
            this.aboutToolStripMenuItem.Text = "About";
            // 
            // applicationToolStripMenuItem
            // 
            this.applicationToolStripMenuItem.Name = "applicationToolStripMenuItem";
            this.applicationToolStripMenuItem.Size = new System.Drawing.Size(135, 22);
            this.applicationToolStripMenuItem.Text = "Application";
            this.applicationToolStripMenuItem.Click += new System.EventHandler(this.applicationToolStripMenuItem_Click);
            // 
            // developerToolStripMenuItem
            // 
            this.developerToolStripMenuItem.Name = "developerToolStripMenuItem";
            this.developerToolStripMenuItem.Size = new System.Drawing.Size(135, 22);
            this.developerToolStripMenuItem.Text = "Developer";
            this.developerToolStripMenuItem.Click += new System.EventHandler(this.developerToolStripMenuItem_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Yellow;
            this.label1.Location = new System.Drawing.Point(226, 36);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(295, 24);
            this.label1.TabIndex = 1;
            this.label1.Text = "School Management System";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(284, 115);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(414, 232);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Blue;
            this.label2.Location = new System.Drawing.Point(280, 363);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(243, 24);
            this.label2.TabIndex = 3;
            this.label2.Text = "All rights reserved with";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Blue;
            this.label3.Location = new System.Drawing.Point(280, 387);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(295, 24);
            this.label3.TabIndex = 4;
            this.label3.Text = "School Management System";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.button1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(68, 115);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(147, 48);
            this.button1.TabIndex = 5;
            this.button1.Text = "Add Student";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.button2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(68, 196);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(147, 48);
            this.button2.TabIndex = 6;
            this.button2.Text = "Exit Application";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gray;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Main Form";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addStudentFormToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addTeacherFormToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addParentsFormToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addCourseFormToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addAttendanceFormToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem studentToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem teacherToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem parentsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem courseToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem attendanceToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem editToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem applicationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem developerToolStripMenuItem;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.ToolStripMenuItem attendanceTeacherToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addTeacherAttendanceFormToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem addClassTimeTableToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addClassNameToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addSectionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addExamToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addExamScoreToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addFeeStructureToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sectionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem examToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem classToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem classNameToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem classTimeTableToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem examToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem examTypeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem examScoreToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
    }
}

