﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace SMS_APP
{
    public partial class TeacherForm : Form
    {
        public TeacherForm()
        {
            InitializeComponent();
            this.MaximizeBox = false;
            this.MinimizeBox = false;
        }

        private void TeacherForm_Load(object sender, EventArgs e)
        {

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {

            SqlConnection con = new SqlConnection("Data Source=DESKTOP-B1GS0NE;Initial Catalog=SMS;Integrated Security=True");


            SqlCommand cmd = new SqlCommand("insert into teacher(teacher_id, teacher_name, nic_no, gender, DOJOINING, QUALIFICATION,mobile_no, address, city) " +
                "values(@teacher_id, @teacher_name, @nic_no, @gender, @DOJOINING, @QUALIFICATION, @mobile_no, @address, @city)", con);


            con.Open();
            cmd.Parameters.AddWithValue("@teacher_id ", txtTeacherId.Text);
            cmd.Parameters.AddWithValue("@teacher_name ", txtName.Text);
            cmd.Parameters.AddWithValue("@nic_no ", txtNicNo.Text);
            cmd.Parameters.AddWithValue("@gender ", txtGender.Text);
            cmd.Parameters.AddWithValue("@DOJOINING ", txtDoj.Text);
            cmd.Parameters.AddWithValue("@QUALIFICATION ", txtQualification.Text);
            cmd.Parameters.AddWithValue("@mobile_no", txtMobNo.Text);
            cmd.Parameters.AddWithValue("@address ", txtAddress.Text);
            cmd.Parameters.AddWithValue("@city ", txtCity.Text);
            

            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Record Inserted Successfully");

        }
    }
}
