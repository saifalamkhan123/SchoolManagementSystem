﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace SMS_APP.Forms
{
    public partial class TimeTableForm : Form
    {
        public TimeTableForm()
        {
            InitializeComponent();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=DESKTOP-B1GS0NE;Initial Catalog=SMS;Integrated Security=True");


            SqlCommand cmd = new SqlCommand("insert into class_time_table(DAY, SUBJECT, FIRST_PERIOD, SECOND_PERIOD, THIRD_PERIOD, FOURTH_PERIOD, FIFTH_PERIOD, SIXTH_PERIOD, SEVENTH_PERIOD, DESCRIPTION) values " +
                "(@DAY, @SUBJECT, @FIRST_PERIOD, @SECOND_PERIOD, @THIRD_PERIOD, @FOURTH_PERIOD, @FIFTH_PERIOD, @SIXTH_PERIOD, @SEVENTH_PERIOD, @DESCRIPTION)", con);


            con.Open();
            cmd.Parameters.AddWithValue("@DAY ", txtDay.Text);
            cmd.Parameters.AddWithValue("@SUBJECT ", txtSubject.Text);
            cmd.Parameters.AddWithValue("@FIRST_PERIOD ", txtFirstPeriod.Text);
            cmd.Parameters.AddWithValue("@SECOND_PERIOD ", txtSecondPeriod.Text);
            cmd.Parameters.AddWithValue("@THIRD_PERIOD ", txtThirdPeriod.Text);
            cmd.Parameters.AddWithValue("@FOURTH_PERIOD ", txtFourthPeriod.Text);
            cmd.Parameters.AddWithValue("@FIFTH_PERIOD ", txtFifthPeriod.Text);
            cmd.Parameters.AddWithValue("@SIXTH_PERIOD ", txtSixthPeriod.Text);
            cmd.Parameters.AddWithValue("@SEVENTH_PERIOD ", txtSeventhPeriod.Text);
            cmd.Parameters.AddWithValue("@DESCRIPTION ", txtDescription.Text);


            int i = cmd.ExecuteNonQuery();



            MessageBox.Show(i + " Record Inserted Successfully");

            txtDay.Text = " ";
            txtSubject.Text = " ";
            txtSecondPeriod.Text = " ";
            txtFirstPeriod.Text = " ";
            txtThirdPeriod.Text = " ";
            txtFourthPeriod.Text = " ";
            txtFifthPeriod.Text = " ";
            txtSixthPeriod.Text = " ";
            txtSeventhPeriod.Text = " ";
            txtDescription.Text = " ";

            txtDay.Focus();

            con.Close();
        }
    }
}
