﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace SMS_APP
{
    public partial class StudentViewForm : Form
    {
        public StudentViewForm()
        {
            InitializeComponent();
            this.MaximizeBox = false;
            this.MinimizeBox = false;
        }



        private void DisplayData()
        {
            SqlConnection con = new SqlConnection("Data Source=DESKTOP-B1GS0NE;Initial Catalog=SMS;Integrated Security=True");

            con.Open();

            
              DataTable dt = new DataTable();
            

            SqlDataAdapter adapt;
            adapt = new SqlDataAdapter("select * from student", con);
            adapt.Fill(dt);
           

            dataGridView1.DataSource = dt;
            con.Close();
        }

        private void StudentViewForm_Load(object sender, EventArgs e)
        {
            dataGridView1.ColumnHeadersDefaultCellStyle.BackColor = Color.LightPink;
            dataGridView1.EnableHeadersVisualStyles = false;

            DisplayData();

        }

        
    }
}
