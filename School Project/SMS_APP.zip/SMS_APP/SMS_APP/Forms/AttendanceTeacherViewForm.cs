﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace SMS_APP.Forms
{
    public partial class AttendanceTeacherViewForm : Form
    {
        public AttendanceTeacherViewForm()
        {
            InitializeComponent();
        }

        private void DisplayData()
        {
            SqlConnection con = new SqlConnection("Data Source=DESKTOP-B1GS0NE;Initial Catalog=SMS;Integrated Security=True");

            con.Open();
            DataTable dt = new DataTable();

            SqlDataAdapter adapt;
            adapt = new SqlDataAdapter("select * from teacher_attendance", con);
            adapt.Fill(dt);
            dgvAttendance.DataSource = dt;
            con.Close();
        }


        private void AttendanceTeacherViewForm_Load(object sender, EventArgs e)
        {
            dgvAttendance.ColumnHeadersDefaultCellStyle.BackColor = Color.LightPink;
            dgvAttendance.EnableHeadersVisualStyles = false;

            DisplayData();

        }
    }
}
