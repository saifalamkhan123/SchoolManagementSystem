﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using SMS_APP.Model;
using SMS_APP.DB;

namespace SMS_APP.Forms
{
    public partial class ExamForm : Form
    {
        public ExamForm()
        {
            InitializeComponent();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {


            try
            {
                exam obj = new exam();
                obj.exam_id = txtExamId.Text;
                obj.exam_type = txtExamType.Text;

                examDb db = new examDb();

                bool isInsertSucces = db.AddItem(obj);

                if (isInsertSucces)
                {
                    MessageBox.Show("Inserted Successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtExamId.Text = " ";
                    txtExamType.Text = " ";

                    txtExamId.Focus();

                }
                else
                {
                    MessageBox.Show("Insertion Failed", "Failure", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error");
            }



        }
    }

}




