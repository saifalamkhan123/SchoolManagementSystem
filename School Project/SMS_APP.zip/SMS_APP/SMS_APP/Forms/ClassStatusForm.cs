﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace SMS_APP.Forms
{
    public partial class ClassStatusForm : Form
    {
        public ClassStatusForm()
        {
            InitializeComponent();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=DESKTOP-B1GS0NE;Initial Catalog=SMS;Integrated Security=True");


            SqlCommand cmd = new SqlCommand("insert into class(class_id, class_name) values (@class_id, @class_name)", con);


            con.Open();
            cmd.Parameters.AddWithValue("@class_id ", txtClassId.Text);
            cmd.Parameters.AddWithValue("@class_name ", txtClassName.Text);
           
            
           int i = cmd.ExecuteNonQuery();

            
                        
            MessageBox.Show( i + " Record Inserted Successfully");

            txtClassId.Text = " ";
            txtClassName.Text = " ";

            txtClassId.Focus();

            con.Close();


        }
    }
}
