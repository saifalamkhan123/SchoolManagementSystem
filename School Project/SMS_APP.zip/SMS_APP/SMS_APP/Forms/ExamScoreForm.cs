﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace SMS_APP.Forms
{
    public partial class ExamScoreForm : Form
    {
        public ExamScoreForm()
        {
            InitializeComponent();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=DESKTOP-B1GS0NE;Initial Catalog=SMS;Integrated Security=True");


            SqlCommand cmd = new SqlCommand("insert into exam_score(class_id, year, course_name, marks, exam_type) values (@class_id, @year, @course_name, @marks, @exam_type)", con);


            con.Open();
            cmd.Parameters.AddWithValue("@class_id ", txtClassId.Text);
            cmd.Parameters.AddWithValue("@year ", txtYear.Text);
            cmd.Parameters.AddWithValue("@course_name ", txtCourseName.Text);
            cmd.Parameters.AddWithValue("@marks ", txtMarks.Text);
            cmd.Parameters.AddWithValue("@exam_type ", txtExamType.Text);



            int i = cmd.ExecuteNonQuery();



            MessageBox.Show(i + " Record Inserted Successfully");

            txtClassId.Text = " ";
            txtCourseName.Text = " ";
            txtYear.Text = " ";
            txtMarks.Text =  " ";
            txtExamType.Text = " ";

            txtClassId.Focus();

            con.Close();
        }
    }
}
