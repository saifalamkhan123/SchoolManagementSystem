﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace SMS_APP
{
    public partial class AttedanceForm : Form
    {
        public AttedanceForm()
        {
            InitializeComponent();
            
        }

        private void AttedanceForm_Load(object sender, EventArgs e)
        {

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=DESKTOP-B1GS0NE;Initial Catalog=SMS;Integrated Security=True");


            SqlCommand cmd = new SqlCommand("insert into attendance_student (ATTENDANCE_ID,STUDENT_NAME, DATE, STATUS,REMARKS,STUDENT_ID) " +
                "values(@ATTENDANCE_ID,@STUDENT_NAME, @DATE, @STATUS,@REMARKS,@STUDENT_ID)", con);


            con.Open();
            cmd.Parameters.AddWithValue("@ATTENDANCE_ID ", txtAttendanceId.Text);
            cmd.Parameters.AddWithValue("@STUDENT_NAME ", txtName.Text);
            cmd.Parameters.AddWithValue("@DATE ", txtDate.Text);
            cmd.Parameters.AddWithValue("@STATUS ", txtStatus.Text);
            cmd.Parameters.AddWithValue("@REMARKS ", txtRemarks.Text);
            cmd.Parameters.AddWithValue("@STUDENT_ID ", txtStudentId.Text);


            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Record Inserted Successfully");
        }

        
    }
}
