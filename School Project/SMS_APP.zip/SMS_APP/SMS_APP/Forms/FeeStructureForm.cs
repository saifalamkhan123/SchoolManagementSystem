﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace SMS_APP.Forms
{
    public partial class FeeStructureForm : Form
    {
        public FeeStructureForm()
        {
            InitializeComponent();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=DESKTOP-B1GS0NE;Initial Catalog=SMS;Integrated Security=True");


            SqlCommand cmd = new SqlCommand("insert into fee_structure(class_id, year, annual_charges, monthly_charges) values (@class_id, @year, @annual_charges, @monthly_charges)", con);


            con.Open();
            cmd.Parameters.AddWithValue("@class_id ", txtClassId.Text);
            cmd.Parameters.AddWithValue("@year ", txtYear.Text);
            cmd.Parameters.AddWithValue("@annual_charges ", txtAnnualCharges.Text);
            cmd.Parameters.AddWithValue("@monthly_charges ", txtMonthlyCharges.Text);
            

            int i = cmd.ExecuteNonQuery();



            MessageBox.Show(i + " Record Inserted Successfully");

            txtClassId.Text = " ";
            txtYear.Text = " ";
            txtMonthlyCharges.Text = " ";
            txtAnnualCharges.Text = " ";

            txtClassId.Focus();

            con.Close();
        }
    }
}
