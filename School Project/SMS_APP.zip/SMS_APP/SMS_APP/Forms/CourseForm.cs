﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace SMS_APP
{
    public partial class CourseForm : Form
    {
        public CourseForm()
        {
            InitializeComponent();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=DESKTOP-B1GS0NE;Initial Catalog=SMS;Integrated Security=True");


            SqlCommand cmd = new SqlCommand("insert into course(course_id, course_name, description, teacher_id) " +
                "values(@course_id, @course_name, @description, @teacher_id)", con);


            con.Open();
            cmd.Parameters.AddWithValue("@course_id ", txtCourseId.Text);
            cmd.Parameters.AddWithValue("@course_name ", txtCourseName.Text);
            cmd.Parameters.AddWithValue("@description ", txtDescription.Text);
            cmd.Parameters.AddWithValue("@teacher_id ", txtTeacherId.Text);
            

            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Record Inserted Successfully");

        }

        

        
    }
}
