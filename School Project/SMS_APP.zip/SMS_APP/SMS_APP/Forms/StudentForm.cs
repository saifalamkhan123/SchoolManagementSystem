﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;

namespace SMS_APP
{
    public partial class StudentForm : Form
    {
        

        public StudentForm()
        {
            InitializeComponent();
            this.MaximizeBox = false;
            this.MinimizeBox = false;
        }

        
        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=DESKTOP-B1GS0NE;Initial Catalog=SMS;Integrated Security=True");
            

            SqlCommand cmd = new SqlCommand(@"insert into student(student_id, student_name, gender, dob, dojoining, class, section, mobile_no, 
                address, city, parents_id,image_name,image_path)
                values(@student_id, @student_name, @gender, @dob, @dojoining, @class, @section, @mobile_no, @address, @city, @parents_id, 
                  @image_name,@image_path)", con);

            
            con.Open();
            cmd.Parameters.AddWithValue("@student_id ",txtid.Text );
            cmd.Parameters.AddWithValue("@student_name ", txtStudentName.Text);
            cmd.Parameters.AddWithValue("@gender ",txtGender.Text );
            cmd.Parameters.AddWithValue("@dob ", txtDOB.Text);
            cmd.Parameters.AddWithValue("@dojoining", txtDOJoin.Text);
            cmd.Parameters.AddWithValue("@class ", txtClass.Text);
            cmd.Parameters.AddWithValue("@section ", txtSection.Text );
            cmd.Parameters.AddWithValue("@mobile_no", txtMobile.Text );
            cmd.Parameters.AddWithValue("@address ", txtAddress.Text );
            cmd.Parameters.AddWithValue("@city ", txtCity.Text );
            cmd.Parameters.AddWithValue("@parents_id ", txtParentId.Text);
            cmd.Parameters.AddWithValue("@image_name ", txtPicName.Text);
            cmd.Parameters.AddWithValue("@image_path ", openFileDialog1.FileName);

            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Record Inserted Successfully");
            

            
        }

        private void btnUpload_Click(object sender, EventArgs e)
        {



            try
            {
                openFileDialog1.Filter = "select image (*.jpg, *.png, *.gif)| *.jpg; *.png; *.gif";
                if (openFileDialog1.ShowDialog() == DialogResult.OK)
                {

                    pictureBox1.Image = Image.FromFile(openFileDialog1.FileName);

                }
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
        }
    }
}
