﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace SMS_APP.Forms
{
    public partial class AttendanceTeacherForm : Form
    {
        public AttendanceTeacherForm()
        {
            InitializeComponent();
        }

        private void AttendanceTeacherForm_Load(object sender, EventArgs e)
        {

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=DESKTOP-B1GS0NE;Initial Catalog=SMS;Integrated Security=True");


            SqlCommand cmd = new SqlCommand("insert into teacher_attendance (ATTENDANCE_ID,teacher_NAME, DATE, STATUS,REMARKS) " +
                "values(@ATTENDANCE_ID,@teacher_NAME, @DATE, @STATUS,@REMARKS)", con);


            con.Open();
            cmd.Parameters.AddWithValue("@ATTENDANCE_ID ", txtAttendanceId.Text);
            cmd.Parameters.AddWithValue("@teacher_NAME ", txtName.Text);
            cmd.Parameters.AddWithValue("@DATE ", txtDate.Text);
            cmd.Parameters.AddWithValue("@STATUS ", txtStatus.Text);
            cmd.Parameters.AddWithValue("@REMARKS ", txtRemarks.Text);
            

            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Record Inserted Successfully");
        }
    }
}
