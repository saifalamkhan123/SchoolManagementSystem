﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace SMS_APP.Forms
{
    public partial class ExamScoreViewForm : Form
    {
        public ExamScoreViewForm()
        {
            InitializeComponent();
        }

        private void DisplayData()
        {
            SqlConnection con = new SqlConnection("Data Source=DESKTOP-B1GS0NE;Initial Catalog=SMS;Integrated Security=True");

            con.Open();
            DataTable dt = new DataTable();

            SqlDataAdapter adapt;
            adapt = new SqlDataAdapter("select * from exam_score", con);
            adapt.Fill(dt);
            dgvExamScore.DataSource = dt;
            con.Close();
        }

        private void ExamScoreViewForm_Load(object sender, EventArgs e)
        {
            dgvExamScore.ColumnHeadersDefaultCellStyle.BackColor = Color.LightPink;
            dgvExamScore.EnableHeadersVisualStyles = false;

            DisplayData();

        }
    }
}
