﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace SMS_APP.Forms
{
    public partial class updateForm : Form
    {

        string code, code1;

        private void updateForm_Load(object sender, EventArgs e)
        {
            

            txtExamId.ReadOnly = true;

            txtExamId.Text = code;
            txtExamType.Text = code1;
        }

     
        private void btnAdd_Click(object sender, EventArgs e)  // update button
        {

            

            code = txtExamId.Text;
            code1 = txtExamType.Text;
            SqlConnection con = new SqlConnection("Data Source=DESKTOP-B1GS0NE;Initial Catalog=SMS;Integrated Security=True");

            con.Open();

            try
            {

                string query = "update exam set exam_type=@exam_type where exam_id = @exam_id";  
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@exam_id", code);
                cmd.Parameters.AddWithValue("@exam_type", code1);
                int result = cmd.ExecuteNonQuery();

                if (result > 0)
                {
                    MessageBox.Show("Data updated Successfully");

                }
                else
                {

                    MessageBox.Show("Data not updated ");

                }

            }

            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);

            }

        }

        public updateForm(string id1, string id2)
        {
            InitializeComponent();

            code = id1;
            code1 = id2;
        }

       
    }
}
