﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace SMS_APP
{
    public partial class ParentsViewForm : Form
    {
        public ParentsViewForm()
        {
            InitializeComponent();
            this.MaximizeBox = false;
            this.MinimizeBox = false;
        }


        private void DisplayData()
        {
            SqlConnection con = new SqlConnection("Data Source=DESKTOP-B1GS0NE;Initial Catalog=SMS;Integrated Security=True");

            con.Open();
            DataTable dt = new DataTable();

            SqlDataAdapter adapt;
            adapt = new SqlDataAdapter("select * from parents", con);
            adapt.Fill(dt);
            dgvParentsDetail.DataSource = dt;
            con.Close();
        }

        private void ParentsViewForm_Load(object sender, EventArgs e)
        {
            dgvParentsDetail.ColumnHeadersDefaultCellStyle.BackColor = Color.LightPink;
            dgvParentsDetail.EnableHeadersVisualStyles = false;
            DisplayData();

        }

       
    }
}
