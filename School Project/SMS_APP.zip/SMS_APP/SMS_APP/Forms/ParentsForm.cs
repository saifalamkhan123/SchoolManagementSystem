﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace SMS_APP
{
    public partial class ParentsForm : Form
    {
        public ParentsForm()
        {
            InitializeComponent();
            this.MaximizeBox = false;
            this.MinimizeBox = false;
        }

        private void ParentsForm_Load(object sender, EventArgs e)
        {

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {

            SqlConnection con = new SqlConnection("Data Source=DESKTOP-B1GS0NE;Initial Catalog=SMS;Integrated Security=True");


            SqlCommand cmd = new SqlCommand("insert into parents(parents_id, parents_name, nic_no, gender, mobile_no, address, city, student_id) " +
                "values(@parents_id, @parents_name, @nic_no, @gender, @mobile_no, @address, @city, @student_id)", con);


            con.Open();
            cmd.Parameters.AddWithValue("@parents_id ", txtParentsId.Text);
            cmd.Parameters.AddWithValue("@parents_name ", txtName.Text);
            cmd.Parameters.AddWithValue("@nic_no ", txtNicNo.Text);
            cmd.Parameters.AddWithValue("@gender ", txtGender.Text);
            cmd.Parameters.AddWithValue("@mobile_no", txtMobNo.Text);
            cmd.Parameters.AddWithValue("@address ", txtAddress.Text);
            cmd.Parameters.AddWithValue("@city ", txtCity.Text);
            cmd.Parameters.AddWithValue("@student_id", txtStudentId.Text);
            
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Record Inserted Successfully");



        }

       
    }
}
