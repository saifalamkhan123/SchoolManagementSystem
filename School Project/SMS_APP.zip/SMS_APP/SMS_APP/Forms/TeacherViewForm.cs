﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace SMS_APP
{
    public partial class TeacherViewForm : Form
    {
        public TeacherViewForm()
        {
            InitializeComponent();
            this.MaximizeBox = false;
            this.MinimizeBox = false;
        }


        private void DisplayData()
        {
            SqlConnection con = new SqlConnection("Data Source=DESKTOP-B1GS0NE;Initial Catalog=SMS;Integrated Security=True");

            con.Open();
            DataTable dt = new DataTable();

            SqlDataAdapter adapt;
            adapt = new SqlDataAdapter("select * from teacher", con);
            adapt.Fill(dt);
            dgvTeacherDetail.DataSource = dt;
            con.Close();
        }


        

        private void TeacherViewForm_Load(object sender, EventArgs e)
        {
            dgvTeacherDetail.ColumnHeadersDefaultCellStyle.BackColor = Color.LightPink;
            dgvTeacherDetail.EnableHeadersVisualStyles = false;
            DisplayData();
        }

       
    }
}
