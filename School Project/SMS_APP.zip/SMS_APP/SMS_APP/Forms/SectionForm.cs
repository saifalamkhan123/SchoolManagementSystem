﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace SMS_APP.Forms
{
    public partial class SectionForm : Form
    {
        public SectionForm()
        {
            InitializeComponent();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=DESKTOP-B1GS0NE;Initial Catalog=SMS;Integrated Security=True");


            SqlCommand cmd = new SqlCommand("insert into section(section_id, description) values (@section_id, @description)", con);


            con.Open();
            cmd.Parameters.AddWithValue("@section_id ", txtSectionId.Text);
            cmd.Parameters.AddWithValue("@description ", txtDescription.Text);


            int i = cmd.ExecuteNonQuery();



            MessageBox.Show(i + " Record Inserted Successfully");

            txtSectionId.Text = " ";
            txtDescription.Text = " ";

            txtSectionId.Focus();

            con.Close();
        }
    }
}
