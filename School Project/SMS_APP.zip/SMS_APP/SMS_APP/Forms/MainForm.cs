﻿using SMS_APP.Forms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SMS_APP
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }



        private void Obj_FormClosed(object sender, FormClosedEventArgs e)
        {
            this.Show();
        }


        private void applicationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ApplicationForm obj = new ApplicationForm();
            obj.Show();
            obj.FormClosed += Obj_FormClosed;



        }

        private void developerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DeveloperForm obj = new DeveloperForm();
            obj.Show();
            obj.FormClosed += Obj_FormClosed;


        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            StudentForm obj = new StudentForm();
            obj.Show();
            obj.FormClosed += Obj_FormClosed;
            
        }

       

        private void addStudentFormToolStripMenuItem_Click(object sender, EventArgs e)
        {


            StudentForm obj = new StudentForm();
            obj.Show();
            obj.FormClosed += Obj_FormClosed;
            


        }

        private void studentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            StudentViewForm obj = new StudentViewForm();
            obj.Show();
            obj.FormClosed += Obj_FormClosed;

        }

        private void addCourseFormToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CourseForm obj = new CourseForm();
            obj.Show();
            obj.FormClosed += Obj_FormClosed;

        }

        private void courseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CourseViewForm obj = new CourseViewForm();
            obj.Show();
            obj.FormClosed += Obj_FormClosed;
        }

        private void addAttendanceFormToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            AttedanceForm obj = new AttedanceForm();
            obj.Show();
            obj.FormClosed += Obj_FormClosed;

        }

        private void attendanceToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AttendanceViewForm obj = new AttendanceViewForm();
            obj.Show();
            obj.FormClosed += Obj_FormClosed;


        }

        private void addParentsFormToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ParentsForm obj = new ParentsForm();
            obj.Show();
            this.FormClosed += Obj_FormClosed;

            
        }

        private void parentsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ParentsViewForm obj = new ParentsViewForm();
            obj.Show();
            obj.FormClosed += Obj_FormClosed;
        }

        private void teacherToolStripMenuItem_Click(object sender, EventArgs e)
        {
            TeacherViewForm obj = new TeacherViewForm();
            obj.Show();
            obj.FormClosed += Obj_FormClosed;

        }

        private void addTeacherFormToolStripMenuItem_Click(object sender, EventArgs e)
        {
            TeacherForm obj = new TeacherForm();
            obj.Show();
            this.FormClosed += Obj_FormClosed;
            
            

        }

       

        private void addTeacherAttendanceFormToolStripMenuItem_Click(object sender, EventArgs e)
        {

            AttendanceTeacherForm obj = new AttendanceTeacherForm();
            obj.Show();
            obj.FormClosed += Obj_FormClosed;


        }

        private void attendanceTeacherToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AttendanceTeacherViewForm obj = new AttendanceTeacherViewForm();
            obj.Show();
            obj.FormClosed += Obj_FormClosed;

        }

        private void classNameToolStripMenuItem_Click(object sender, EventArgs e)
        {

            ClassStatusViewForm obj = new ClassStatusViewForm();
            obj.Show();
            obj.FormClosed += Obj_FormClosed;


        }

        private void classTimeTableToolStripMenuItem_Click(object sender, EventArgs e)
        {
            TimeTableViewForm obj = new TimeTableViewForm();
            obj.Show();
            obj.FormClosed += Obj_FormClosed;


        }

        private void examTypeToolStripMenuItem_Click(object sender, EventArgs e)
        {

            ExamViewForm obj = new ExamViewForm();
            obj.Show();
            obj.FormClosed += Obj_FormClosed;


        }

        private void examScoreToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ExamScoreViewForm obj = new ExamScoreViewForm();
            obj.Show();
            obj.FormClosed += Obj_FormClosed;

        }

        private void sectionToolStripMenuItem_Click(object sender, EventArgs e)
        {

            SectionViewForm obj = new SectionViewForm();
            obj.Show();
            obj.FormClosed += Obj_FormClosed;

        }

        private void examToolStripMenuItem_Click(object sender, EventArgs e)  // fee structure
        {

            FeeStructureViewForm obj = new FeeStructureViewForm();
            obj.Show();
            obj.FormClosed += Obj_FormClosed;


        }

        private void addClassTimeTableToolStripMenuItem_Click(object sender, EventArgs e)
        {
            TimeTableForm obj = new TimeTableForm();
            obj.Show();
            obj.FormClosed += Obj_FormClosed;


        }

        private void addClassNameToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ClassStatusForm obj = new ClassStatusForm();
            obj.Show();
            obj.FormClosed += Obj_FormClosed;
        }

        private void addSectionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SectionForm obj = new SectionForm();
            obj.Show();
            obj.FormClosed += Obj_FormClosed;

        }

        private void addExamToolStripMenuItem_Click(object sender, EventArgs e)
        {

            ExamForm obj = new ExamForm();
            obj.Show();
            obj.FormClosed += Obj_FormClosed;

        }

        private void addExamScoreToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ExamScoreForm obj = new ExamScoreForm();
            obj.Show();
            obj.FormClosed += Obj_FormClosed;

        }

        private void addFeeStructureToolStripMenuItem_Click(object sender, EventArgs e)
        {

            FeeStructureForm obj = new FeeStructureForm();
            obj.Show();
            obj.FormClosed += Obj_FormClosed;

        }
    }
}
