﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace SMS_APP.Forms
{
    public partial class ExamViewForm : Form
    {
        public ExamViewForm()
        {
            InitializeComponent();
        }


        public void DisplayData()
        {
            SqlConnection con = new SqlConnection("Data Source=DESKTOP-B1GS0NE;Initial Catalog=SMS;Integrated Security=True");

            con.Open();
            DataTable dt = new DataTable();

            SqlDataAdapter adapt;
            adapt = new SqlDataAdapter("select * from exam", con);
            adapt.Fill(dt);
            dgvExam.DataSource = dt;
            con.Close();
        }

        private void ExamViewForm_Load(object sender, EventArgs e)
        {
            dgvExam.ColumnHeadersDefaultCellStyle.BackColor = Color.LightPink;
            dgvExam.EnableHeadersVisualStyles = false;
            DisplayData();

        }

        private void dgvExam_CellClick(object sender, DataGridViewCellEventArgs e)
        {

            try
            {

                if (dgvExam.Columns[e.ColumnIndex].HeaderText == "UPDATE")
            {

                string id1, id2;
                id1 = dgvExam.Rows[e.RowIndex].Cells["EXAM_ID"].Value.ToString();
                id2 = dgvExam.Rows[e.RowIndex].Cells["EXAM_TYPE"].Value.ToString();

                updateForm obj = new updateForm(id1, id2);
                obj.ShowDialog();

            }




            if (dgvExam.Columns[e.ColumnIndex].HeaderText == "DELETE")
            {

                string message = "Do you want to delete this record?";
                string title = "Confirmation!";
                MessageBoxButtons buttons = MessageBoxButtons.YesNo;
                DialogResult result = MessageBox.Show(message, title, buttons);
                if (result == DialogResult.Yes)
                {

                    string id;
                    id = dgvExam.Rows[e.RowIndex].Cells["EXAM_ID"].Value.ToString();
                    SqlConnection con = new SqlConnection("Data Source=DESKTOP-B1GS0NE;Initial Catalog=SMS;Integrated Security=True");

                    con.Open();

                   

                        string query = "delete from exam where EXAM_ID=@code";  // we let any variable name like @code , exam_id is the database id
                        SqlCommand cmd = new SqlCommand(query, con);
                        cmd.Parameters.AddWithValue("@code", id);
                        int result1 = cmd.ExecuteNonQuery();

                        if (result1 > 0)
                        {
                            MessageBox.Show("Data Deleted Successfully");
                            DisplayData();
                        }
                        else
                        {

                            this.Close();

                        }
                   
                }

                
            }


            }

            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);

            }
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            DisplayData();
        }
    }
}

       
    
