﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;



namespace SMS_APP.Forms
{
    public partial class SectionViewForm : Form
    {
        public SectionViewForm()
        {
            InitializeComponent();
        }

        private void DisplayData()
        {
            SqlConnection con = new SqlConnection("Data Source=DESKTOP-B1GS0NE;Initial Catalog=SMS;Integrated Security=True");

            con.Open();
            DataTable dt = new DataTable();

            SqlDataAdapter adapt;
            adapt = new SqlDataAdapter("select * from section", con);
            adapt.Fill(dt);
            dgvSection.DataSource = dt;
            con.Close();
        }

        private void SectionViewForm_Load(object sender, EventArgs e)
        {

            dgvSection.ColumnHeadersDefaultCellStyle.BackColor = Color.LightPink;
            dgvSection.EnableHeadersVisualStyles = false;
            DisplayData();

        }
    }
}
