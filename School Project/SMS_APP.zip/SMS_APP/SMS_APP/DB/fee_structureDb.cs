﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS_APP.DB
{
    public class fee_structureDb
    {

        public int class_id;
        public int year;
        public int monthly_charges;
        public int annual_charges;
    }
}
