﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS_APP.DB
{
    public class exam_scoreDb
    {

        public string class_id;
        public int year;
        public string course_name;
        public int marks;
        public string exam_type;
    }
}
