﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS_APP.DB
{
    public class class_time_tableDb
    {
        public string day;
        public string SUBJECT;
        public string FIRST_PERIOD;
        public string SECOND_PERIOD;
        public string THIRD_PERIOD;
        public string FOURTH_PERIOD;
        public string FIFTH_PERIOD;
        public string SIXTH_PERIOD;
        public string SEVENTH_PERIOD;
    }
}
