﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS_APP.Model
{
    public class ParentsDb
    {
        public int parentsId;
        public string parentsName;
        public int nicNo;
        public string gender;
        public int mobileNo;
        public string Address;
        public string city;
        public int studentId;

    }
}

