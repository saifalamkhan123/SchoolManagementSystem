﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using SMS_APP.Model;

namespace SMS_APP.DB
{
    public class examDb
    {


        SqlConnection con = new SqlConnection("Data Source=DESKTOP-B1GS0NE;Initial Catalog=SMS;Integrated Security=True");
        public bool AddItem(exam obj)
        {
           
            try
            {

                string query = "insert into exam values (@exam_id, @exam_type)";
                SqlCommand com = new SqlCommand(query, con);
                com.Parameters.AddWithValue("@exam_id", obj.exam_id);
                com.Parameters.AddWithValue("@exam_type", obj.exam_type);
             
                con.Open();
                int a = com.ExecuteNonQuery();
                if (a > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }




        }


    }
}
